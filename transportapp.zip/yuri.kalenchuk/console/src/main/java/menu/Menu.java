package menu;

public interface Menu {
    void printTextMenu();

    void printMenu();
}
