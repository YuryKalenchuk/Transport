package dao.interfaces;

public interface AdminDAO {

}
